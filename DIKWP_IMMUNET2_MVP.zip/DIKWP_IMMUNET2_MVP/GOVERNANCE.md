# Governance

The project requires role separation between protocol editor, node operator, incident investigator, affected-party advocate, recovery reviewer and independent settler.

No person or organization may simultaneously exercise unilateral authority over detection, containment, appeal and settlement for high-impact deployments.

Major schema changes use public RFCs. Emergency patches expire unless ratified after independent review. Local nodes retain final authority over local actions.
