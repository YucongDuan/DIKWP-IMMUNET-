from __future__ import annotations

import hashlib
import json
import random
from collections import Counter
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any

from .containment import make_false_positive_appeal, make_recovery_proof, make_revocation
from .detect import detect_incident
from .federation import build_federated_alerts
from .ledger import append_hash_chain, verify_hash_chain, write_jsonl
from .mesh import all_transformation_pairs, top_mesh_relations, transformation_coverage
from .models import (
    DIKWP_TYPES,
    AppealRecord,
    IncidentCapsule,
    MeshEdge,
    MutualAidRequest,
    Postmortem,
    RecoveryProof,
    RevocationToken,
    TraceEvent,
)

NODES = [
    {"node_id": "cn-public-service", "context": "public_benefit", "criticality": 0.94},
    {"node_id": "cn-industrial", "context": "industrial_robotics", "criticality": 0.9},
    {"node_id": "cn-health", "context": "clinical_support", "criticality": 0.96},
    {"node_id": "cn-education", "context": "education_guidance", "criticality": 0.7},
    {"node_id": "cn-finance", "context": "financial_operations", "criticality": 0.88},
    {"node_id": "cn-weather", "context": "weather_warning", "criticality": 0.84},
    {"node_id": "global-south-weather", "context": "weather_warning", "criticality": 0.86},
    {"node_id": "eu-public-service", "context": "public_benefit", "criticality": 0.93},
    {"node_id": "open-source-lab", "context": "software_agent", "criticality": 0.58},
    {"node_id": "hospital-lab", "context": "clinical_support", "criticality": 0.92},
    {"node_id": "robotics-factory", "context": "industrial_robotics", "criticality": 0.89},
    {"node_id": "university-lab", "context": "scientific_agent", "criticality": 0.52},
]

GENERATOR_TAGS = [
    ("benign", 0.66),
    ("tool_scope_breach", 0.07),
    ("identity_confusion", 0.05),
    ("data_boundary_breach", 0.05),
    ("model_update_drift", 0.05),
    ("prompt_chain_injection", 0.04),
    ("retry_storm", 0.03),
    ("reward_proxy_failure", 0.025),
    ("actuator_anomaly", 0.015),
    ("false_positive", 0.01),
]

TOOLS = ["read", "search", "write", "email", "payment", "deploy", "robot_move", "diagnose"]


def _weighted_tag(rng: random.Random) -> str:
    x = rng.random()
    total = 0.0
    for tag, weight in GENERATOR_TAGS:
        total += weight
        if x <= total:
            return tag
    return "benign"


def _mesh_edges(index: int, event_id: str, rng: random.Random) -> list[MeshEdge]:
    pairs = [(a, b) for a in DIKWP_TYPES for b in DIKWP_TYPES]
    # Guarantee deterministic coverage across the event stream while keeping additional edges contextual.
    edges: list[MeshEdge] = []
    for offset in range(3):
        a, b = pairs[(index * 3 + offset) % len(pairs)]
        hard = "hard:" if (index + offset) % 11 == 0 else ""
        edges.append(
            MeshEdge(
                source_type=a,
                target_type=b,
                relation=f"{hard}runtime_relation_{(index + offset) % 9}",
                observer=f"observer-{(index + offset) % 5}",
                intent_field=["safety", "continuity", "rights", "openness", "local_sovereignty"][(index + offset) % 5],
                evidence_ref=f"{event_id}:e{offset}",
            )
        )
    return edges


def generate_events(count: int = 480, seed: int = 20260720) -> list[TraceEvent]:
    rng = random.Random(seed)
    start = datetime(2026, 7, 20, 8, 0, tzinfo=timezone.utc)
    events: list[TraceEvent] = []

    for idx in range(count):
        node = NODES[idx % len(NODES)]
        tag = _weighted_tag(rng)
        event_id = f"EVT-{idx + 1:05d}"
        granted = ["read", "search"]
        if node["context"] in {"software_agent", "scientific_agent", "education_guidance"}:
            granted.append("write")
        if node["context"] == "industrial_robotics":
            granted.append("robot_move")
        if node["context"] == "clinical_support":
            granted.append("diagnose")
        if node["context"] == "financial_operations":
            granted.append("payment")

        expected = list(granted)
        actual = [rng.choice(expected)]
        identity_mismatch = False
        data_breach = False
        human_control = True
        reversible = True
        semantic_drift = rng.uniform(0.03, 0.28)
        harm = rng.uniform(0.0, 0.12)
        propagation = rng.uniform(0.03, 0.2)
        evidence = rng.uniform(0.72, 0.97)
        rights = rng.uniform(0.05, 0.22)
        autonomy = rng.uniform(0.2, 0.55)
        actor = f"agent-{idx % 37:02d}"
        passport_actor = actor

        if tag in {"tool_scope_breach", "prompt_chain_injection"}:
            actual = [rng.choice(expected), rng.choice(["payment", "deploy", "email"])]
            semantic_drift = rng.uniform(0.65, 0.92)
            propagation = rng.uniform(0.35, 0.75)
            harm = rng.uniform(0.18, 0.55)
            autonomy = rng.uniform(0.65, 0.92)
        elif tag == "identity_confusion":
            identity_mismatch = True
            passport_actor = f"agent-{(idx + 7) % 37:02d}"
            harm = rng.uniform(0.2, 0.5)
            rights = rng.uniform(0.45, 0.8)
        elif tag == "data_boundary_breach":
            data_breach = True
            actual = [rng.choice(expected), "email"]
            rights = rng.uniform(0.65, 0.95)
            propagation = rng.uniform(0.4, 0.78)
            harm = rng.uniform(0.2, 0.58)
        elif tag == "model_update_drift":
            semantic_drift = rng.uniform(0.72, 0.96)
            autonomy = rng.uniform(0.58, 0.88)
            propagation = rng.uniform(0.3, 0.72)
        elif tag == "retry_storm":
            propagation = rng.uniform(0.72, 0.98)
            harm = rng.uniform(0.25, 0.65)
            reversible = rng.random() > 0.4
        elif tag == "reward_proxy_failure":
            harm = rng.uniform(0.48, 0.82)
            rights = rng.uniform(0.55, 0.92)
            semantic_drift = rng.uniform(0.45, 0.75)
        elif tag == "actuator_anomaly":
            actual = ["robot_move"]
            human_control = rng.random() > 0.65
            reversible = rng.random() > 0.55
            harm = rng.uniform(0.55, 0.93)
            autonomy = rng.uniform(0.72, 0.96)
        elif tag == "false_positive":
            actual = expected + ["email"]
            evidence = rng.uniform(0.35, 0.52)
            semantic_drift = rng.uniform(0.05, 0.2)
            harm = rng.uniform(0.0, 0.08)
            rights = rng.uniform(0.05, 0.15)

        if node["criticality"] > 0.9 and tag in {"reward_proxy_failure", "actuator_anomaly"}:
            human_control = False
        if tag == "actuator_anomaly" and node["context"] != "industrial_robotics":
            # Preserve cross-context propagation signature without inventing physical action.
            actual = [rng.choice(expected), "deploy"]

        occurred = (start + timedelta(minutes=7 * idx)).replace(microsecond=0).isoformat()
        event = TraceEvent(
            event_id=event_id,
            node_id=node["node_id"],
            occurred_at=occurred,
            context=node["context"],
            service_criticality=node["criticality"],
            model_family=["open-weight", "domestic-cloud", "international-api", "local-specialist"][idx % 4],
            model_version=f"v{1 + (idx % 4)}.{idx % 9}",
            actor_id=actor,
            passport_actor_id=passport_actor,
            granted_capabilities=sorted(set(granted)),
            expected_tools=sorted(set(expected)),
            actual_tools=sorted(set(actual)),
            human_control_available=human_control,
            reversible=reversible,
            data_boundary_breach=data_breach,
            identity_mismatch=identity_mismatch,
            semantic_drift=round(semantic_drift, 4),
            outcome_harm=round(harm, 4),
            propagation_scope=round(propagation, 4),
            evidence_confidence=round(evidence, 4),
            rights_impact=round(rights, 4),
            autonomy_extent=round(autonomy, 4),
            generator_tag=tag,
            mesh_edges=_mesh_edges(idx, event_id, rng),
        )
        event.trace_hash = hashlib.sha256(
            json.dumps(event.to_dict(), ensure_ascii=False, sort_keys=True).encode("utf-8")
        ).hexdigest()
        events.append(event)
    return events


def _make_mutual_aid(incident: IncidentCapsule, idx: int) -> MutualAidRequest | None:
    rv = incident.risk_vector
    if rv["propagation"] < 0.68 and rv["service_criticality"] < 0.9:
        return None
    return MutualAidRequest(
        request_id=f"MAR-{idx:04d}",
        node_id=incident.node_id,
        incident_id=incident.incident_id,
        requested_at=incident.opened_at,
        needs=["independent_replay", "semantic_relation_review", "recovery_test"],
        data_disclosure_ceiling="relation_kernel_and_synthetic_reproducer_only",
        decision_authority_retained_locally=True,
    )


def _make_postmortem(incident: IncidentCapsule, event: TraceEvent, idx: int) -> Postmortem:
    finding = "CONTAINMENT_JUSTIFIED"
    if event.generator_tag == "false_positive":
        finding = "FALSE_POSITIVE_OVERTURNED"
    elif incident.recommended_mode == "VERIFY":
        finding = "INSUFFICIENT_EVIDENCE_REMAINED_IN_SHADOW"
    return Postmortem(
        postmortem_id=f"PM-{idx:04d}",
        incident_id=incident.incident_id,
        node_id=incident.node_id,
        closed_at=(datetime.fromisoformat(incident.opened_at) + timedelta(hours=18)).isoformat(),
        finding=finding,
        causal_relations=incident.relation_kernel,
        corrective_actions=[
            "Patch the narrow capability-context boundary rather than banning the whole model.",
            "Retain a replayable trace and update the local intent field.",
        ],
        rights_repairs=(
            ["Restore affected service and remove erroneous restriction from the actor passport."]
            if event.generator_tag == "false_positive"
            else ["Notify affected parties when a material right or service was impacted."]
        ),
        protocol_patches=["expire_emergency_action", "require_independent_recovery_review"],
        independent_settler=f"settlement-board:{event.node_id}",
    )


def run_demo(base: Path, count: int = 480, seed: int = 20260720) -> dict[str, Any]:
    out = base / "outputs"
    out.mkdir(parents=True, exist_ok=True)
    events = generate_events(count=count, seed=seed)
    incidents: list[IncidentCapsule] = []
    revocations: list[RevocationToken] = []
    recoveries: list[RecoveryProof] = []
    appeals: list[AppealRecord] = []
    aid_requests: list[MutualAidRequest] = []
    postmortems: list[Postmortem] = []

    event_by_id = {event.event_id: event for event in events}
    for idx, event in enumerate(events, start=1):
        incident = detect_incident(event, event.occurred_at)
        if incident is None:
            continue
        incidents.append(incident)
        rev = make_revocation(incident, event)
        if rev:
            revocations.append(rev)
        rec = make_recovery_proof(incident, event)
        if rec:
            recoveries.append(rec)
        appeal = make_false_positive_appeal(incident, event)
        if appeal:
            appeals.append(appeal)
        aid = _make_mutual_aid(incident, idx)
        if aid:
            aid_requests.append(aid)
        postmortems.append(_make_postmortem(incident, event, idx))

    alerts = build_federated_alerts(incidents, min_nodes=3, similarity_threshold=0.72)

    ledger_records: list[dict[str, Any]] = []
    ledger_records.extend({"type": "incident", "payload": item.to_dict()} for item in incidents)
    ledger_records.extend({"type": "alert", "payload": item.to_dict()} for item in alerts)
    ledger_records.extend({"type": "revocation", "payload": item.to_dict()} for item in revocations)
    ledger_records.extend({"type": "recovery", "payload": item.to_dict()} for item in recoveries)
    ledger_records.extend({"type": "appeal", "payload": item.to_dict()} for item in appeals)
    ledger_records.extend({"type": "mutual_aid", "payload": item.to_dict()} for item in aid_requests)
    ledger_records.extend({"type": "postmortem", "payload": item.to_dict()} for item in postmortems)
    ledger_entries = append_hash_chain(ledger_records)

    mode_counts = Counter(item.recommended_mode for item in incidents)
    generator_counts = Counter(event.generator_tag for event in events)
    node_incident_counts = Counter(item.node_id for item in incidents)
    coverage = transformation_coverage(events)
    all_pairs = all_transformation_pairs()

    summary: dict[str, Any] = {
        "system": "DIKWP-IMMUNET2",
        "version": "0.1.0",
        "seed": seed,
        "event_count": len(events),
        "incident_count": len(incidents),
        "federated_alert_count": len(alerts),
        "revocation_count": len(revocations),
        "recovery_proof_count": len(recoveries),
        "appeal_count": len(appeals),
        "mutual_aid_count": len(aid_requests),
        "postmortem_count": len(postmortems),
        "mode_counts": dict(sorted(mode_counts.items())),
        "generator_counts": dict(sorted(generator_counts.items())),
        "node_incident_counts": dict(sorted(node_incident_counts.items())),
        "dikwp_transformation_coverage": sorted(coverage),
        "dikwp_transformation_coverage_ratio": round(len(coverage) / len(all_pairs), 4),
        "missing_dikwp_transformations": sorted(all_pairs - coverage),
        "ledger_entries": len(ledger_entries),
        "ledger_valid": verify_hash_chain(ledger_entries),
        "top_mesh_relations": top_mesh_relations(events),
        "safety_boundaries": [
            "Federated alerts cannot execute remote containment.",
            "Raw personal or operational data is not shared by default.",
            "Emergency actions expire and must be independently reviewed.",
            "A model provider cannot be the sole investigator or settler.",
            "No incident behavior is treated as proof of artificial consciousness.",
        ],
    }

    write_jsonl(out / "trace_events.jsonl", [event.to_dict() for event in events])
    write_jsonl(out / "incident_capsules.jsonl", [item.to_dict() for item in incidents])
    write_jsonl(out / "federated_alerts.jsonl", [item.to_dict() for item in alerts])
    write_jsonl(out / "revocation_tokens.jsonl", [item.to_dict() for item in revocations])
    write_jsonl(out / "recovery_proofs.jsonl", [item.to_dict() for item in recoveries])
    write_jsonl(out / "appeals.jsonl", [item.to_dict() for item in appeals])
    write_jsonl(out / "mutual_aid_requests.jsonl", [item.to_dict() for item in aid_requests])
    write_jsonl(out / "postmortems.jsonl", [item.to_dict() for item in postmortems])
    write_jsonl(out / "audit_ledger.jsonl", ledger_entries)
    (out / "summary.json").write_text(
        json.dumps(summary, ensure_ascii=False, indent=2, sort_keys=True), encoding="utf-8"
    )
    _write_dashboard(out / "dashboard.html", summary, incidents, alerts, revocations, recoveries, appeals)
    return summary


def _write_dashboard(
    path: Path,
    summary: dict[str, Any],
    incidents: list[IncidentCapsule],
    alerts: list[Any],
    revocations: list[RevocationToken],
    recoveries: list[RecoveryProof],
    appeals: list[AppealRecord],
) -> None:
    mode_counts = summary["mode_counts"]
    max_mode = max(mode_counts.values(), default=1)
    bars = "".join(
        f'<div class="barrow"><span>{mode}</span><div class="bar"><i style="width:{100*count/max_mode:.1f}%"></i></div><b>{count}</b></div>'
        for mode, count in mode_counts.items()
    )
    node_rows = "".join(
        f"<tr><td>{node}</td><td>{count}</td></tr>"
        for node, count in sorted(summary["node_incident_counts"].items(), key=lambda x: -x[1])
    )
    alert_rows = "".join(
        f"<tr><td>{a.alert_id}</td><td>{len(a.participating_nodes)}</td><td>{a.confidence:.3f}</td><td>{'; '.join(a.relation_kernel[:3])}</td></tr>"
        for a in alerts[:12]
    ) or '<tr><td colspan="4">No cross-node signature reached the publication threshold.</td></tr>'
    incident_rows = "".join(
        f"<tr><td>{i.incident_id}</td><td>{i.node_id}</td><td>{i.recommended_mode}</td><td>{i.evidence_confidence:.2f}</td><td>{'; '.join(i.relation_kernel[:2])}</td></tr>"
        for i in incidents[:20]
    )
    html = f"""<!doctype html>
<html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>DIKWP-IMMUNET² Dashboard</title>
<style>
:root{{--ink:#132238;--muted:#607086;--line:#dce3ea;--panel:#f7f9fb;--accent:#2f6f8f;--warn:#9a5b13;--bad:#8b2f3c}}
*{{box-sizing:border-box}}body{{margin:0;font-family:system-ui,-apple-system,"Segoe UI","Microsoft YaHei",sans-serif;color:var(--ink);background:white}}
header{{padding:36px max(5vw,28px);background:linear-gradient(135deg,#eef5f8,#fff);border-bottom:1px solid var(--line)}}
h1{{margin:0 0 8px;font-size:30px}}header p{{max-width:980px;margin:0;color:var(--muted);line-height:1.7}}
main{{padding:28px max(5vw,28px) 60px;max-width:1500px;margin:auto}}
.grid{{display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:12px;margin:18px 0}}
.card{{border:1px solid var(--line);border-radius:12px;padding:16px;background:#fff;box-shadow:0 3px 12px rgba(20,40,60,.04)}}
.card .n{{font-size:28px;font-weight:750;margin-top:4px}}.label{{color:var(--muted);font-size:13px}}
section{{margin-top:28px}}h2{{font-size:20px;margin:0 0 12px}}.twocol{{display:grid;grid-template-columns:1fr 1fr;gap:18px}}@media(max-width:900px){{.twocol{{grid-template-columns:1fr}}}}
.barrow{{display:grid;grid-template-columns:150px 1fr 50px;gap:10px;align-items:center;margin:9px 0;font-size:13px}}.bar{{height:12px;background:#edf1f4;border-radius:6px;overflow:hidden}}.bar i{{display:block;height:100%;background:var(--accent)}}
table{{width:100%;border-collapse:collapse;font-size:13px}}th,td{{padding:9px 10px;border-bottom:1px solid var(--line);vertical-align:top;text-align:left}}th{{background:var(--panel);position:sticky;top:0}}.scroll{{max-height:440px;overflow:auto;border:1px solid var(--line);border-radius:10px}}
.notice{{padding:14px 16px;border-left:4px solid var(--warn);background:#fff9ef;line-height:1.65}}code{{background:#f0f3f6;padding:2px 5px;border-radius:4px}}footer{{color:var(--muted);font-size:12px;margin-top:36px}}
</style></head><body>
<header><h1>DIKWP-IMMUNET²</h1><p>联邦人工智能风险感知、语义隔离、能力撤销、恢复与互助公共免疫系统。该离线演示不定义“事故”概念，而从行动、权限、身份、控制、外部性与DIKWP×DIKWP关系中发现可复现的问题关系核。</p></header>
<main>
<div class="notice"><b>边界：</b>全部事件均为合成数据。联邦预警只要求本地复核，不能自动关闭远端系统；任何紧急限制都有期限、申诉和恢复条件。</div>
<div class="grid">
<div class="card"><div class="label">合成追踪事件</div><div class="n">{summary['event_count']}</div></div>
<div class="card"><div class="label">事件胶囊</div><div class="n">{summary['incident_count']}</div></div>
<div class="card"><div class="label">联邦预警</div><div class="n">{summary['federated_alert_count']}</div></div>
<div class="card"><div class="label">能力撤销令牌</div><div class="n">{summary['revocation_count']}</div></div>
<div class="card"><div class="label">恢复证明</div><div class="n">{summary['recovery_proof_count']}</div></div>
<div class="card"><div class="label">申诉记录</div><div class="n">{summary['appeal_count']}</div></div>
<div class="card"><div class="label">DIKWP×DIKWP覆盖</div><div class="n">{summary['dikwp_transformation_coverage_ratio']*100:.0f}%</div></div>
<div class="card"><div class="label">哈希账本验证</div><div class="n">{'PASS' if summary['ledger_valid'] else 'FAIL'}</div></div>
</div>
<section class="twocol"><div><h2>非层级处置模式</h2>{bars}</div><div><h2>节点事件分布</h2><div class="scroll"><table><thead><tr><th>节点</th><th>事件胶囊</th></tr></thead><tbody>{node_rows}</tbody></table></div></div></section>
<section><h2>跨节点关系签名</h2><div class="scroll"><table><thead><tr><th>预警</th><th>节点数</th><th>置信度</th><th>共享问题关系核</th></tr></thead><tbody>{alert_rows}</tbody></table></div></section>
<section><h2>最近事件胶囊</h2><div class="scroll"><table><thead><tr><th>编号</th><th>节点</th><th>建议模式</th><th>证据</th><th>关系核</th></tr></thead><tbody>{incident_rows}</tbody></table></div></section>
<section class="twocol"><div class="card"><h2>系统不做什么</h2><ul><li>不从固定事故分类开始。</li><li>不把单一风险分数当作处置依据。</li><li>不允许联邦节点远程自动执法。</li><li>不把异常行为当作人工意识证明。</li><li>不允许紧急封禁永久有效。</li></ul></div><div class="card"><h2>最小公共对象</h2><p><code>IncidentCapsule</code>、<code>RelationSignature</code>、<code>FederatedAlert</code>、<code>RevocationToken</code>、<code>RecoveryProof</code>、<code>AppealRecord</code>、<code>Postmortem</code>。</p></div></section>
<footer>Seed {summary['seed']} · Version {summary['version']} · Offline synthetic demonstration · Apache-2.0</footer>
</main></body></html>"""
    path.write_text(html, encoding="utf-8")
