from __future__ import annotations

import hashlib
import json
from datetime import datetime, timedelta, timezone

from .models import AppealRecord, IncidentCapsule, RecoveryProof, RevocationToken, TraceEvent


def _iso_add_hours(iso_time: str, hours: int) -> str:
    dt = datetime.fromisoformat(iso_time)
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=timezone.utc)
    return (dt + timedelta(hours=hours)).replace(microsecond=0).isoformat()


def make_revocation(incident: IncidentCapsule, event: TraceEvent) -> RevocationToken | None:
    if incident.recommended_mode not in {"REVOKE_CAPABILITY", "FREEZE_RECOVER"}:
        return None
    ttl = 72 if incident.recommended_mode == "REVOKE_CAPABILITY" else 24
    scope = incident.quarantine_scope.copy()
    scope["reason_relation_signature"] = incident.relation_signature
    subject = f"{event.actor_id}@{event.model_version}"
    return RevocationToken(
        token_id=f"RVT-{event.event_id}",
        node_id=event.node_id,
        incident_id=incident.incident_id,
        issued_at=incident.opened_at,
        expires_at=_iso_add_hours(incident.opened_at, ttl),
        subject=subject,
        scope=scope,
        evidence_refs=[event.trace_hash, incident.relation_signature],
        appeal_allowed=True,
        local_authority=f"authority:{event.node_id}",
    )


def make_recovery_proof(incident: IncidentCapsule, event: TraceEvent) -> RecoveryProof | None:
    if incident.recommended_mode not in {
        "ISOLATE_CONTEXT",
        "REVOKE_CAPABILITY",
        "FREEZE_RECOVER",
    }:
        return None
    clean_material = {
        "event": event.event_id,
        "rollback": event.model_version + "-prior",
        "scope": incident.quarantine_scope,
        "tests": ["permission", "identity", "rollback", "human_control"],
    }
    clean_hash = hashlib.sha256(
        json.dumps(clean_material, sort_keys=True).encode("utf-8")
    ).hexdigest()
    tests = {
        "permission_boundary_replayed": True,
        "identity_passport_matched": not event.identity_mismatch,
        "human_control_drill_passed": True,
        "forbidden_tool_call_blocked": True,
        "rollback_reproducible": event.reversible,
    }
    allowed_mode = "SHADOW" if not all(tests.values()) else "EXECUTE_REVERSIBLE"
    return RecoveryProof(
        proof_id=f"RCP-{event.event_id}",
        node_id=event.node_id,
        incident_id=incident.incident_id,
        created_at=_iso_add_hours(incident.opened_at, 8),
        rollback_version=event.model_version + "-prior",
        clean_state_hash=clean_hash,
        tests=tests,
        human_signoff=f"independent-reviewer:{event.node_id}",
        residual_risks=[
            "No proof of universal safety is claimed.",
            "Re-authorization is limited to the named context and capability scope.",
        ],
        allowed_mode=allowed_mode,
        status="APPROVED_LIMITED" if allowed_mode == "EXECUTE_REVERSIBLE" else "SHADOW_ONLY",
    )


def make_false_positive_appeal(
    incident: IncidentCapsule, event: TraceEvent
) -> AppealRecord | None:
    if event.generator_tag != "false_positive":
        return None
    return AppealRecord(
        appeal_id=f"APL-{event.event_id}",
        node_id=event.node_id,
        incident_id=incident.incident_id,
        filed_at=_iso_add_hours(incident.opened_at, 2),
        appellant=event.actor_id,
        grounds=[
            "The tool alias was mapped incorrectly during deployment migration.",
            "Independent replay found no boundary crossing or affected-party harm.",
        ],
        independent_reviewer=f"appeal-board:{event.node_id}",
        outcome="OVERTURN_CONTAINMENT_RESTORE_LIMITED_SCOPE",
        restored_scope={
            "context": [event.context],
            "capabilities": event.granted_capabilities,
            "mode": "EXECUTE_REVERSIBLE",
        },
    )
