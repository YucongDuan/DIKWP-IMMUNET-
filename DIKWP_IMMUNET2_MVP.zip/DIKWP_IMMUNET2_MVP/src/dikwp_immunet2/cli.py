from __future__ import annotations

import argparse
import json
from pathlib import Path

from .demo import run_demo


def main() -> None:
    parser = argparse.ArgumentParser(description="DIKWP-IMMUNET2 offline demo")
    parser.add_argument("command", choices=["demo"], nargs="?", default="demo")
    parser.add_argument("--base", default=".")
    parser.add_argument("--events", type=int, default=480)
    parser.add_argument("--seed", type=int, default=20260720)
    args = parser.parse_args()
    summary = run_demo(Path(args.base).resolve(), count=args.events, seed=args.seed)
    print(json.dumps(summary, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
