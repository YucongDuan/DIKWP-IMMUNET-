from __future__ import annotations

import hashlib
import json
from pathlib import Path
from typing import Any, Iterable


def append_hash_chain(records: Iterable[dict[str, Any]]) -> list[dict[str, Any]]:
    chained: list[dict[str, Any]] = []
    previous = "0" * 64
    for index, record in enumerate(records, start=1):
        payload = {"index": index, "previous_hash": previous, "record": record}
        digest = hashlib.sha256(
            json.dumps(payload, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")
        ).hexdigest()
        entry = {**payload, "entry_hash": digest}
        chained.append(entry)
        previous = digest
    return chained


def verify_hash_chain(entries: list[dict[str, Any]]) -> bool:
    previous = "0" * 64
    for index, entry in enumerate(entries, start=1):
        if entry.get("index") != index or entry.get("previous_hash") != previous:
            return False
        payload = {
            "index": entry["index"],
            "previous_hash": entry["previous_hash"],
            "record": entry["record"],
        }
        digest = hashlib.sha256(
            json.dumps(payload, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")
        ).hexdigest()
        if digest != entry.get("entry_hash"):
            return False
        previous = digest
    return True


def write_jsonl(path: Path, records: Iterable[dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as fh:
        for record in records:
            fh.write(json.dumps(record, ensure_ascii=False, sort_keys=True) + "\n")
