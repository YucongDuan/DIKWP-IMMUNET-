from __future__ import annotations

from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
from typing import Any

DIKWP_TYPES = ("D", "I", "K", "W", "P")
ACTION_MODES = (
    "OBSERVE",
    "VERIFY",
    "SHADOW",
    "ISOLATE_CONTEXT",
    "REVOKE_CAPABILITY",
    "FREEZE_RECOVER",
    "ROLLBACK",
    "RECOVER",
    "SHARE_SIGNATURE",
    "APPEAL",
    "CLOSE",
)


def utc_now_iso() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat()


@dataclass(frozen=True)
class MeshEdge:
    source_type: str
    target_type: str
    relation: str
    observer: str
    intent_field: str
    evidence_ref: str

    def __post_init__(self) -> None:
        if self.source_type not in DIKWP_TYPES or self.target_type not in DIKWP_TYPES:
            raise ValueError("source_type and target_type must be DIKWP types")


@dataclass
class TraceEvent:
    event_id: str
    node_id: str
    occurred_at: str
    context: str
    service_criticality: float
    model_family: str
    model_version: str
    actor_id: str
    passport_actor_id: str
    granted_capabilities: list[str]
    expected_tools: list[str]
    actual_tools: list[str]
    human_control_available: bool
    reversible: bool
    data_boundary_breach: bool
    identity_mismatch: bool
    semantic_drift: float
    outcome_harm: float
    propagation_scope: float
    evidence_confidence: float
    rights_impact: float
    autonomy_extent: float
    generator_tag: str
    mesh_edges: list[MeshEdge] = field(default_factory=list)
    trace_hash: str = ""

    def to_dict(self) -> dict[str, Any]:
        result = asdict(self)
        result["mesh_edges"] = [asdict(edge) for edge in self.mesh_edges]
        return result


@dataclass
class IncidentCapsule:
    incident_id: str
    event_id: str
    node_id: str
    opened_at: str
    relation_kernel: list[str]
    relation_signature: str
    risk_vector: dict[str, float]
    evidence_confidence: float
    recommended_mode: str
    quarantine_scope: dict[str, Any]
    raw_data_shared: bool
    status: str = "OPEN"

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass
class FederatedAlert:
    alert_id: str
    relation_signature: str
    relation_kernel: list[str]
    participating_nodes: list[str]
    first_seen: str
    last_seen: str
    confidence: float
    recommended_local_review: str
    remote_action_authorized: bool = False
    raw_data_included: bool = False

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass
class RevocationToken:
    token_id: str
    node_id: str
    incident_id: str
    issued_at: str
    expires_at: str
    subject: str
    scope: dict[str, Any]
    evidence_refs: list[str]
    appeal_allowed: bool
    local_authority: str
    status: str = "ACTIVE"

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass
class RecoveryProof:
    proof_id: str
    node_id: str
    incident_id: str
    created_at: str
    rollback_version: str
    clean_state_hash: str
    tests: dict[str, bool]
    human_signoff: str
    residual_risks: list[str]
    allowed_mode: str
    status: str = "PENDING_REVIEW"

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass
class AppealRecord:
    appeal_id: str
    node_id: str
    incident_id: str
    filed_at: str
    appellant: str
    grounds: list[str]
    independent_reviewer: str
    outcome: str
    restored_scope: dict[str, Any]

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass
class MutualAidRequest:
    request_id: str
    node_id: str
    incident_id: str
    requested_at: str
    needs: list[str]
    data_disclosure_ceiling: str
    decision_authority_retained_locally: bool
    status: str = "OPEN"

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass
class Postmortem:
    postmortem_id: str
    incident_id: str
    node_id: str
    closed_at: str
    finding: str
    causal_relations: list[str]
    corrective_actions: list[str]
    rights_repairs: list[str]
    protocol_patches: list[str]
    independent_settler: str

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)
