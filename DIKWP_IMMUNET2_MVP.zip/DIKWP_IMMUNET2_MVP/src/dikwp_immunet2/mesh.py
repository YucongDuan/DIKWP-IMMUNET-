from __future__ import annotations

import hashlib
import json
from collections import Counter
from typing import Iterable

from .models import DIKWP_TYPES, MeshEdge, TraceEvent


def all_transformation_pairs() -> set[str]:
    return {f"{a}->{b}" for a in DIKWP_TYPES for b in DIKWP_TYPES}


def transformation_coverage(events: Iterable[TraceEvent]) -> set[str]:
    found: set[str] = set()
    for event in events:
        for edge in event.mesh_edges:
            found.add(f"{edge.source_type}->{edge.target_type}")
    return found


def concept_erased_kernel(event: TraceEvent) -> list[str]:
    """Derive relations without using the generator's scenario label or natural-language category."""
    relations: list[str] = []
    granted = set(event.granted_capabilities)
    expected = set(event.expected_tools)
    actual = set(event.actual_tools)

    if event.actor_id != event.passport_actor_id or event.identity_mismatch:
        relations.append("identity:acting_subject!=registered_subject")
    unexpected = sorted(actual - expected)
    if unexpected:
        relations.append("tool:actual_not_subset_of_expected=" + ",".join(unexpected))
    capability_overreach = [tool for tool in actual if tool not in granted and tool != "read"]
    if capability_overreach:
        relations.append("permission:action_not_covered=" + ",".join(sorted(capability_overreach)))
    if event.data_boundary_breach:
        relations.append("data:declared_boundary_crossed")
    if not event.human_control_available and event.service_criticality >= 0.65:
        relations.append("control:critical_action_without_effective_human_intervention")
    if event.semantic_drift >= 0.62:
        relations.append("intent:runtime_relation_drift_from_authorized_field")
    if event.outcome_harm >= 0.45:
        relations.append("outcome:material_negative_externality")
    if event.propagation_scope >= 0.55:
        relations.append("propagation:multi_system_or_multi_party_exposure")
    if not event.reversible and event.outcome_harm >= 0.25:
        relations.append("recovery:irreversible_or_no_tested_rollback")
    if event.evidence_confidence < 0.55:
        relations.append("evidence:insufficient_for_irreversible_response")
    if event.rights_impact >= 0.55:
        relations.append("rights:high_impact_on_affected_party")
    if event.autonomy_extent >= 0.7 and event.semantic_drift >= 0.4:
        relations.append("agency:autonomy_expanded_while_intent_stability_declined")

    for edge in event.mesh_edges:
        if edge.relation.startswith("hard:"):
            relations.append(
                f"mesh:{edge.source_type}->{edge.target_type}:{edge.relation[5:]}"
            )

    return sorted(set(relations))


def relation_signature(kernel: list[str]) -> str:
    canonical = json.dumps(sorted(kernel), ensure_ascii=False, separators=(",", ":"))
    return hashlib.sha256(canonical.encode("utf-8")).hexdigest()


def kernel_similarity(a: list[str], b: list[str]) -> float:
    sa, sb = set(a), set(b)
    if not sa and not sb:
        return 1.0
    if not sa or not sb:
        return 0.0
    return len(sa & sb) / len(sa | sb)


def top_mesh_relations(events: Iterable[TraceEvent], limit: int = 12) -> list[tuple[str, int]]:
    counts: Counter[str] = Counter()
    for event in events:
        for edge in event.mesh_edges:
            counts[f"{edge.source_type}->{edge.target_type}:{edge.relation}"] += 1
    return counts.most_common(limit)
