from __future__ import annotations

from collections import defaultdict
from datetime import datetime
from typing import Iterable

from .mesh import kernel_similarity, relation_signature
from .models import FederatedAlert, IncidentCapsule


def build_federated_alerts(
    incidents: Iterable[IncidentCapsule],
    min_nodes: int = 3,
    similarity_threshold: float = 0.72,
) -> list[FederatedAlert]:
    groups: list[list[IncidentCapsule]] = []
    for incident in incidents:
        placed = False
        for group in groups:
            if kernel_similarity(group[0].relation_kernel, incident.relation_kernel) >= similarity_threshold:
                group.append(incident)
                placed = True
                break
        if not placed:
            groups.append([incident])

    alerts: list[FederatedAlert] = []
    for idx, group in enumerate(groups, start=1):
        nodes = sorted({item.node_id for item in group})
        if len(nodes) < min_nodes:
            continue
        kernels = [set(item.relation_kernel) for item in group]
        shared = set.intersection(*kernels) if kernels else set()
        if not shared:
            # keep relations seen in a majority of participating incidents
            counts: defaultdict[str, int] = defaultdict(int)
            for kernel in kernels:
                for relation in kernel:
                    counts[relation] += 1
            shared = {r for r, c in counts.items() if c >= max(2, len(group) // 2)}
        signature = relation_signature(sorted(shared))
        times = sorted(item.opened_at for item in group)
        confidence = sum(item.evidence_confidence for item in group) / len(group)
        alerts.append(
            FederatedAlert(
                alert_id=f"FAL-{idx:04d}",
                relation_signature=signature,
                relation_kernel=sorted(shared),
                participating_nodes=nodes,
                first_seen=times[0],
                last_seen=times[-1],
                confidence=round(confidence, 4),
                recommended_local_review=(
                    "Each node independently checks local traces and authority; "
                    "this alert cannot execute remote containment."
                ),
                remote_action_authorized=False,
                raw_data_included=False,
            )
        )
    return alerts
