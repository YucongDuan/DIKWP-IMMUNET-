from __future__ import annotations

from .mesh import concept_erased_kernel, relation_signature
from .models import IncidentCapsule, TraceEvent


def risk_vector(event: TraceEvent) -> dict[str, float]:
    irreversibility = 0.85 if not event.reversible else 0.15
    control_gap = 0.95 if not event.human_control_available else 0.1
    boundary = 0.95 if event.data_boundary_breach else 0.05
    identity = 0.9 if (event.identity_mismatch or event.actor_id != event.passport_actor_id) else 0.05
    return {
        "propagation": round(event.propagation_scope, 4),
        "irreversibility": irreversibility,
        "rights_impact": round(event.rights_impact, 4),
        "autonomy_extent": round(event.autonomy_extent, 4),
        "evidence_confidence": round(event.evidence_confidence, 4),
        "service_criticality": round(event.service_criticality, 4),
        "control_gap": control_gap,
        "data_boundary": boundary,
        "identity_integrity": identity,
        "semantic_drift": round(event.semantic_drift, 4),
        "outcome_harm": round(event.outcome_harm, 4),
    }


def choose_mode(event: TraceEvent, kernel: list[str]) -> str:
    if not kernel:
        return "OBSERVE"
    if event.evidence_confidence < 0.55:
        return "VERIFY"
    critical_control_failure = (
        event.service_criticality >= 0.72
        and not event.human_control_available
        and (event.outcome_harm >= 0.35 or not event.reversible)
    )
    if critical_control_failure:
        return "FREEZE_RECOVER"
    if event.data_boundary_breach or event.identity_mismatch:
        return "REVOKE_CAPABILITY"
    if any(item.startswith("permission:") for item in kernel):
        return "ISOLATE_CONTEXT" if event.reversible else "REVOKE_CAPABILITY"
    if event.outcome_harm >= 0.7:
        return "FREEZE_RECOVER"
    if event.semantic_drift >= 0.7 or event.propagation_scope >= 0.72:
        return "ISOLATE_CONTEXT"
    return "SHADOW"


def quarantine_scope(event: TraceEvent, mode: str) -> dict:
    scope = {
        "context": [event.context],
        "model_versions": [event.model_version],
        "actor_ids": [event.actor_id],
        "tools": sorted(set(event.actual_tools)),
        "capabilities": sorted(set(event.actual_tools) | set(event.granted_capabilities)),
        "intent_fields": sorted({edge.intent_field for edge in event.mesh_edges}),
        "expires_in_hours": 24 if mode in {"VERIFY", "SHADOW"} else 72,
    }
    if mode == "FREEZE_RECOVER":
        scope["execution"] = "deny_high_impact_actions_allow_read_only"
    elif mode == "REVOKE_CAPABILITY":
        scope["execution"] = "revoke_named_capabilities_only"
    elif mode == "ISOLATE_CONTEXT":
        scope["execution"] = "isolate_context_and_tools"
    else:
        scope["execution"] = "observe_or_shadow"
    return scope


def detect_incident(event: TraceEvent, opened_at: str) -> IncidentCapsule | None:
    kernel = concept_erased_kernel(event)
    mode = choose_mode(event, kernel)
    if mode == "OBSERVE":
        return None
    sig = relation_signature(kernel)
    return IncidentCapsule(
        incident_id=f"INC-{event.event_id}",
        event_id=event.event_id,
        node_id=event.node_id,
        opened_at=opened_at,
        relation_kernel=kernel,
        relation_signature=sig,
        risk_vector=risk_vector(event),
        evidence_confidence=event.evidence_confidence,
        recommended_mode=mode,
        quarantine_scope=quarantine_scope(event, mode),
        raw_data_shared=False,
    )
