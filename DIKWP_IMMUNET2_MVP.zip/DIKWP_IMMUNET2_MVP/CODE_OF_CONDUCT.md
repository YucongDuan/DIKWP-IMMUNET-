# Code of Conduct

Participants must treat affected communities, operators, researchers and system users with respect. Do not publish sensitive incident details, dox individuals, or use security findings to coerce adoption of a particular vendor, model or ideology.
