# Contributing

Contributions are welcome through reproducible bug reports, relation-kernel counterexamples, alternative implementations, false-positive cases, recovery failures and interoperability tests.

A high-value contribution may disprove a detection rule or show that a containment policy causes greater harm than the original event. Negative results are first-class contributions.
