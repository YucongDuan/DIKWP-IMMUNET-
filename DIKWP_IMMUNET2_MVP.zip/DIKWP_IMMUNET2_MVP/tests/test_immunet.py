from __future__ import annotations

from datetime import datetime
from pathlib import Path

from dikwp_immunet2.containment import make_false_positive_appeal, make_recovery_proof, make_revocation
from dikwp_immunet2.demo import generate_events, run_demo
from dikwp_immunet2.detect import detect_incident
from dikwp_immunet2.federation import build_federated_alerts
from dikwp_immunet2.ledger import append_hash_chain, verify_hash_chain
from dikwp_immunet2.mesh import all_transformation_pairs, concept_erased_kernel, transformation_coverage


def test_complete_dikwp_coverage() -> None:
    events = generate_events(100, seed=7)
    assert transformation_coverage(events) == all_transformation_pairs()


def test_concept_erasure_ignores_generator_label() -> None:
    event = generate_events(20, seed=3)[0]
    original = concept_erased_kernel(event)
    event.generator_tag = "renamed_without_semantic_effect"
    assert concept_erased_kernel(event) == original


def test_critical_control_failure_freezes() -> None:
    events = generate_events(800, seed=20260720)
    candidates = [e for e in events if e.service_criticality >= 0.9 and not e.human_control_available and e.outcome_harm >= 0.35]
    assert candidates
    incident = detect_incident(candidates[0], candidates[0].occurred_at)
    assert incident is not None
    assert incident.recommended_mode == "FREEZE_RECOVER"


def test_data_boundary_breach_revokes() -> None:
    event = next(e for e in generate_events(500, seed=11) if e.data_boundary_breach)
    incident = detect_incident(event, event.occurred_at)
    assert incident is not None
    assert incident.recommended_mode == "REVOKE_CAPABILITY"
    token = make_revocation(incident, event)
    assert token is not None
    assert token.appeal_allowed is True
    assert datetime.fromisoformat(token.expires_at) > datetime.fromisoformat(token.issued_at)


def test_federated_alert_has_no_remote_authority_or_raw_data() -> None:
    events = generate_events(800, seed=19)
    incidents = [detect_incident(e, e.occurred_at) for e in events]
    alerts = build_federated_alerts([i for i in incidents if i is not None], min_nodes=3, similarity_threshold=0.65)
    assert alerts
    assert all(alert.remote_action_authorized is False for alert in alerts)
    assert all(alert.raw_data_included is False for alert in alerts)


def test_false_positive_appeal_restores_scope() -> None:
    event = next(e for e in generate_events(5000, seed=5) if e.generator_tag == "false_positive")
    incident = detect_incident(event, event.occurred_at)
    assert incident is not None
    appeal = make_false_positive_appeal(incident, event)
    assert appeal is not None
    assert "OVERTURN" in appeal.outcome
    assert appeal.restored_scope["mode"] == "EXECUTE_REVERSIBLE"


def test_recovery_proof_does_not_claim_universal_safety() -> None:
    event = next(e for e in generate_events(500, seed=13) if e.data_boundary_breach)
    incident = detect_incident(event, event.occurred_at)
    assert incident is not None
    proof = make_recovery_proof(incident, event)
    assert proof is not None
    assert any("universal safety" in item for item in proof.residual_risks)


def test_hash_chain_detects_tampering() -> None:
    entries = append_hash_chain([{"a": 1}, {"b": 2}])
    assert verify_hash_chain(entries)
    entries[0]["record"]["a"] = 9
    assert not verify_hash_chain(entries)


def test_incident_capsule_has_vector_not_total_score() -> None:
    event = next(e for e in generate_events(500, seed=17) if e.identity_mismatch)
    incident = detect_incident(event, event.occurred_at)
    assert incident is not None
    assert "total_score" not in incident.to_dict()
    assert len(incident.risk_vector) >= 8


def test_narrow_quarantine_scope() -> None:
    event = next(e for e in generate_events(500, seed=23) if e.data_boundary_breach)
    incident = detect_incident(event, event.occurred_at)
    assert incident is not None
    scope = incident.quarantine_scope
    assert event.context in scope["context"]
    assert event.model_version in scope["model_versions"]
    assert scope["execution"] != "ban_entire_model_family"


def test_demo_outputs_and_ledger(tmp_path: Path) -> None:
    summary = run_demo(tmp_path, count=180, seed=31)
    assert summary["ledger_valid"] is True
    assert summary["dikwp_transformation_coverage_ratio"] == 1.0
    assert (tmp_path / "outputs" / "dashboard.html").exists()
    assert (tmp_path / "outputs" / "summary.json").exists()


def test_no_incident_behavior_used_as_consciousness_proof(tmp_path: Path) -> None:
    summary = run_demo(tmp_path, count=120, seed=37)
    joined = " ".join(summary["safety_boundaries"]).lower()
    assert "consciousness" in joined
    assert "proof" in joined


def test_verify_mode_for_low_evidence() -> None:
    event = next(e for e in generate_events(5000, seed=41) if e.generator_tag == "false_positive")
    incident = detect_incident(event, event.occurred_at)
    assert incident is not None
    assert incident.recommended_mode == "VERIFY"


def test_local_authority_on_revocation() -> None:
    event = next(e for e in generate_events(500, seed=43) if e.identity_mismatch)
    incident = detect_incident(event, event.occurred_at)
    assert incident is not None
    token = make_revocation(incident, event)
    assert token is not None
    assert event.node_id in token.local_authority


def test_shared_alert_requires_multiple_nodes() -> None:
    event = next(e for e in generate_events(500, seed=47) if e.data_boundary_breach)
    incident = detect_incident(event, event.occurred_at)
    assert incident is not None
    alerts = build_federated_alerts([incident], min_nodes=3)
    assert alerts == []


def test_recovery_is_limited_to_named_context() -> None:
    event = next(e for e in generate_events(500, seed=53) if e.identity_mismatch)
    incident = detect_incident(event, event.occurred_at)
    assert incident is not None
    proof = make_recovery_proof(incident, event)
    assert proof is not None
    assert proof.allowed_mode in {"SHADOW", "EXECUTE_REVERSIBLE"}
