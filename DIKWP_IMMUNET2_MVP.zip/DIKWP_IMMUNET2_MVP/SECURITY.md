# Security Policy

This repository is a synthetic, offline reference implementation. Do not submit real personal data, credentials, operational secrets or critical-infrastructure traces in public issues.

Report vulnerabilities privately to the designated maintainers of the eventual canonical repository. A production deployment must add authenticated signing, key rotation, authorization, secure transport, data-loss prevention, audit retention and independent recovery review.
